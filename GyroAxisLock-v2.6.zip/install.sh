SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

print_modname() {
  ui_print " "
  ui_print "[=================================]"
  ui_print "   Gyro Axis Lock v2.6 Ultra-Fast "
  ui_print "     Anti-Flip & 1000Hz Raw Gyro   "
  ui_print "            by kerems            "
  ui_print "[=================================]"
  ui_print " "
}

on_install() {
  sleep 1
  ui_print "+.+.+ Preparing Installation ..."
  ui_print " "
  sleep 1
  ui_print "+.+.+ Locking Gyroscope Axis ..."
  ui_print " "
  sleep 2
  ui_print "+.+.+ Successfully Installed Gyro Axis Lock v2.6 ..."
  ui_print " "
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}
