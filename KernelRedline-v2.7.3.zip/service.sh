#!/system/bin/sh

MODDIR="${0%/*}"
export AKTUNE_MODDIR="$MODDIR"
. "$MODDIR/common/util.sh"

aktune_prepare_dirs
rotate_logs_if_needed

log_i "service: waiting for boot completion"
wait_boot_completed 180 || { log_w "service: boot incomplete; tuning skipped"; exit 0; }
akt_sleep 5

if aktune_daemon_running; then
  log_i "service: daemon already running"
  exit 0
fi

log_i "service: starting adaptive daemon (supervised)"

if [ -w "/proc/$$/oom_score_adj" ]; then
  echo "-1000" > "/proc/$$/oom_score_adj" 2>/dev/null
fi

while :; do
  if ! aktune_daemon_running; then
    log_w "service: daemon not running, (re)starting"
    sh "$MODDIR/tweaks/daemon.sh" >> "$LOG_FILE" 2>&1 &
  fi
  sleep 5
done
