#!/system/bin/sh

SKIPUNZIP=0

print_modname() {
  ui_print "****************************************"
  ui_print " Kernel Redline v2.7.3 (OnePlus 13 Edition)"
  ui_print " Dual-Mode: Aggressive <-> Stock"
  ui_print " Priority mode + WALT + Adreno 830 profiles"
  ui_print " Installer: kerems | based on AKTune (NSLabs)"
  ui_print "****************************************"
}

on_install() {
  ui_print "- Installing Kernel Redline v2.7.3 files..."
  mkdir -p /data/adb/aktune/state /data/adb/aktune/logs 2>/dev/null
  
  if [ -f "/data/adb/aktune/config.props" ]; then
    ui_print "- Backing up existing config to config.props.bak..."
    cp "/data/adb/aktune/config.props" "/data/adb/aktune/config.props.bak" 2>/dev/null
  fi
  ui_print "- Applying new v2.7.3 Ultra performance config..."
  cp "$MODPATH/common/config.default.props" "/data/adb/aktune/config.props" 2>/dev/null

  # Default active mode: aggressive
  echo "aggressive" > /data/adb/aktune/state/force_mode
  rm -f /data/adb/aktune/state/daemon.*.lock 2>/dev/null
  rm -f /data/adb/aktune/state/daemon.pid 2>/dev/null
}

set_permissions() {
  ui_print "- Setting permissions..."

  set_perm_recursive "$MODPATH" 0 0 0755 0644

  set_perm "$MODPATH/aktune.sh" 0 0 0755
  set_perm "$MODPATH/service.sh" 0 0 0755
  set_perm "$MODPATH/action.sh" 0 0 0755
  set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
  set_perm "$MODPATH/uninstall.sh" 0 0 0755

  set_perm_recursive "$MODPATH/common" 0 0 0755 0644
  set_perm_recursive "$MODPATH/tweaks" 0 0 0755 0644

  chmod 0755 "$MODPATH/aktune.sh" "$MODPATH/service.sh" "$MODPATH/action.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/uninstall.sh" 2>/dev/null
  chmod 0755 "$MODPATH/common/"*.sh 2>/dev/null
  chmod 0755 "$MODPATH/tweaks/"*.sh 2>/dev/null
}
