#!/system/bin/sh
# AKTune adaptive daemon

MODDIR="${0%/*}/.."
export AKTUNE_MODDIR="$MODDIR"

. "$MODDIR/common/util.sh"
. "$MODDIR/common/sysfs.sh"
. "$MODDIR/common/detect.sh"

brestore() {
  baseline_restore_node "$1" >/dev/null 2>&1 || true
}

now_ms() {
  if [ -r /proc/uptime ]; then
    read -r up _ < /proc/uptime 2>/dev/null

    sec="${up%%.*}"
    frac="${up#*.}"

    # Pad to at least 3 digits
    frac3="${frac}000"

    # Keep first 3 chars of frac3
    case "$frac3" in
      ???*)
        rest="${frac3#???}"
        [ -n "$rest" ] && frac3="${frac3%$rest}"
        ;;
      *)
        frac3="000"
        ;;
    esac

    # Force base-10 to avoid octal issues with leading zeros
    echo $((sec * 1000 + 10#$frac3))
    return 0
  fi

  echo 0
  return 0
}

MODE_FILE_DEFAULT="$STATE_DIR/force_mode"

read_forced_mode() {
  mf="${1:-$MODE_FILE_DEFAULT}"
  m="$(read_first_line "$mf" 2>/dev/null)"
  m="$(akt_trim_ws "$m")"
  case "$m" in
    aggressive) echo "aggressive" ;;
    stock|strict) echo "stock" ;;
    *) echo "aggressive" ;;
  esac
}

get_policies() {
  for p in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] && echo "$p"
  done
}

get_policy_max_freq() {
  f=""
  if [ -e "$1/cpuinfo_max_freq" ]; then
    read -r f < "$1/cpuinfo_max_freq" 2>/dev/null
  fi
  echo "$f"
}

get_max_all_freq() {
  max=0
  for p in $(get_policies); do
    f="$(get_policy_max_freq "$p")"
    case "$f" in
      ""|*[!0-9]*) continue ;;
    esac
    [ "$f" -gt "$max" ] && max="$f"
  done
  echo "$max"
}

policy_tier() {
  p="$1"
  max_all="$2"
  f="$(get_policy_max_freq "$p")"

  case "$f" in
    ""|*[!0-9]*) echo "big"; return 0 ;;
  esac

  local other heterogeneous min_f of
  heterogeneous=0
  min_f="$max_all"
  for other in $(get_policies); do
    of="$(get_policy_max_freq "$other")"
    case "$of" in ""|*[!0-9]*) continue ;; esac
    [ "$of" != "$f" ] && heterogeneous=1
    [ "$of" -lt "$min_f" ] && min_f="$of"
  done
  [ "$heterogeneous" -eq 0 ] && { echo "big"; return 0; }

  # Snapdragon 8 Elite (SM8750): Oryon 6 Performance + 2 Prime cores (no little cores)
  if [ "$min_f" -gt 3000000 ] || [ "$((min_f * 100 / max_all))" -ge 65 ]; then
    if [ "$f" -ge "$max_all" ]; then
      echo "prime"
    else
      echo "big"
    fi
    return 0
  fi

  little_th=$((max_all * 60 / 100))
  big_th=$((max_all * 85 / 100))

  if [ "$f" -le "$little_th" ]; then
    echo "little"
  elif [ "$f" -le "$big_th" ]; then
    echo "big"
  else
    echo "prime"
  fi
}

apply_schedutil_policy() {
  local p tier mode cur su up down
  p="$1"
  tier="$2"
  mode="$3"
  su="$p/schedutil"
  if [ "$mode" = "off" ]; then
    brestore "$su/up_rate_limit_us"
    brestore "$su/down_rate_limit_us"
    brestore "$su/rate_limit_us"
    return 0
  fi

  # The vendor Power HAL may depend on its chosen governor.
  cur="$(read_node "$p/scaling_governor")"
  [ "$(akt_trim_ws "$cur")" = "schedutil" ] || return 0
  [ -d "$su" ] || return 0
  up="$(get_prop_range "cpu.schedutil.on.$tier.up" 6000 500 1000000)"
  down="$(get_prop_range "cpu.schedutil.on.$tier.down" 20000 500 1000000)"
  if [ -e "$su/up_rate_limit_us" ] && [ -e "$su/down_rate_limit_us" ]; then
    write_node "$su/up_rate_limit_us" "$up"
    write_node "$su/down_rate_limit_us" "$down"
  else
    write_node_if_exists "$su/rate_limit_us" "$up"
  fi
}

apply_walt_policy() {
  # Qualcomm WALT governor (Android 14+ GKI, OnePlus 13 / SD 8 Elite)
  # Tuning lives under $policy/walt/ — independent of schedutil.
  local p tier mode wdir up down hispeed_load
  p="$1"
  tier="$2"
  mode="$3"
  wdir="$p/walt"
  [ -d "$wdir" ] || return 0

  if [ "$mode" = "off" ]; then
    brestore "$wdir/up_rate_limit_us"
    brestore "$wdir/down_rate_limit_us"
    brestore "$wdir/hispeed_load"
    brestore "$wdir/hispeed_freq"
    return 0
  fi

  cur="$(read_node "$p/scaling_governor")"
  [ "$(akt_trim_ws "$cur")" = "walt" ] || return 0

  up="$(get_prop_range "cpu.walt.on.$tier.up" 500 0 1000000)"
  down="$(get_prop_range "cpu.walt.on.$tier.down" 30000 0 1000000)"
  hispeed_load="$(get_prop_range "cpu.walt.on.$tier.hispeed_load" 75 1 100)"

  write_node_if_exists "$wdir/up_rate_limit_us" "$up"
  write_node_if_exists "$wdir/down_rate_limit_us" "$down"
  write_node_if_exists "$wdir/hispeed_load" "$hispeed_load"
}

apply_cpufreq_boost() {
  local node
  for node in /sys/devices/system/cpu/cpufreq/boost /sys/module/cpufreq_boost/parameters/boost; do
    if [ "$1" = "on" ] && [ "$(get_prop_bool cpu.cpufreq_boost.enable 0)" -eq 1 ]; then
      write_node_if_exists "$node" "1"
    else
      brestore "$node"
    fi
  done
}

apply_cpu_profile() {
  mode="$1"
  [ "$HAS_CPUFREQ" -eq 1 ] || return 0

  max_all="$(get_max_all_freq)"

  for p in $(get_policies); do
    tier="$(policy_tier "$p" "$max_all")"
    apply_schedutil_policy "$p" "$tier" "$mode"
    apply_walt_policy "$p" "$tier" "$mode"
  done

  apply_cpufreq_boost "$mode"
}

cg_find_group() {
  g="$1"

  if [ -d "/sys/fs/cgroup/$g" ]; then
    echo "/sys/fs/cgroup/$g"
    return 0
  fi

  for a in /sys/fs/cgroup/*; do
    [ -d "$a" ] || continue

    if [ -d "$a/$g" ]; then
      echo "$a/$g"
      return 0
    fi

    for b in "$a"/*; do
      [ -d "$b" ] || continue
      if [ -d "$b/$g" ]; then
        echo "$b/$g"
        return 0
      fi
      for c in "$b"/*; do
        [ -d "$c" ] || continue
        if [ -d "$c/$g" ]; then
          echo "$c/$g"
          return 0
        fi
      done
    done
  done

  return 1
}

apply_uclamp_profile() {
  local inter_min node
  if [ "$HAS_UCLAMP" -eq 1 ]; then
    if [ "$1" = "on" ]; then
      inter_min="$(get_prop_range uclamp.top.min.interactive 512 0 1024)"
      set_topapp_min_all_bases "$inter_min"
    else
      for node in $(topapp_min_nodes); do brestore "$node"; done
    fi
  fi
  if [ "$1" = "on" ] && [ "$(get_prop_bool sched.boost.enable 0)" -eq 1 ]; then
    write_node_if_exists /proc/sys/kernel/sched_boost 1
    write_node_if_exists /proc/sys/walt/sched_boost 1
  else
    brestore /proc/sys/kernel/sched_boost
    brestore /proc/sys/walt/sched_boost
  fi
  if [ "$1" = "on" ] && [ "$(get_prop_bool sched.low_latency.enable 0)" -eq 1 ]; then
    write_node_if_exists /proc/sys/walt/sched_low_latency 1
    write_node_if_exists /proc/sys/walt/walt_low_latency_task_threshold 20
  else
    brestore /proc/sys/walt/sched_low_latency
    brestore /proc/sys/walt/walt_low_latency_task_threshold
  fi
}

apply_touchboost() {
  local node value ms
  if [ "$(get_prop_bool touchboost.enable 0)" -ne 1 ]; then
    # Do not touch or restore touch nodes when disabled, allowing ReactTouch to control them
    return 0
  fi
  ms="$(get_prop_range touchboost.ms 150 0 500)"
  for node in \
    /sys/module/msm_performance/parameters/touchboost \
    /sys/kernel/msm_performance/touchboost \
    /sys/module/cpu_boost/parameters/input_boost_ms \
    /sys/kernel/cpu_input_boost/input_boost_ms \
    /sys/kernel/cpu_input_boost/enabled \
    /sys/devices/system/cpu/cpu_boost/input_boost_ms \
    /proc/sys/walt/input_boost/input_boost_ms; do
    if [ "$1" = "on" ]; then
      value=1
      case "$node" in */input_boost_ms) value="$ms" ;; esac
      write_node_if_exists "$node" "$value"
    else
      brestore "$node"
    fi
  done
}

gpu_nodes_iter() {
  for d in /sys/class/devfreq/*; do
    [ -d "$d" ] || continue
    [ -e "$d/governor" ] || continue
    name="${d##*/}"
    case "$name" in
      *gpu*|*GPU*|*kgsl*|*KGSL*|*mali*|*Mali*|*adreno*|*Adreno*)
        echo "$d"
        ;;
    esac
  done

  [ -d /sys/class/kgsl/kgsl-3d0/devfreq ] && echo "/sys/class/kgsl/kgsl-3d0/devfreq"
  for d in /sys/devices/platform/soc/*kgsl-3d0/devfreq/*; do
    [ -d "$d" ] && [ -e "$d/governor" ] && echo "$d"
  done
}

_gpu_scan_freq_tokens() {
  d="$1"
  target="$2"
  min=0
  max=0
  best=0
  af="$d/available_frequencies"

  if [ ! -e "$af" ]; then
    echo "0 0 0"
    return 0
  fi

  while IFS= read -r line; do
    set -f
    # shellcheck disable=SC2086
    set -- $line
    set +f
    for x in "$@"; do
      case "$x" in
        ""|*[!0-9]*) continue ;;
      esac
      if [ "$min" -eq 0 ] || [ "$x" -lt "$min" ]; then
        min="$x"
      fi
      [ "$x" -gt "$max" ] && max="$x"
      if [ "$x" -ge "$target" ]; then
        if [ "$best" -eq 0 ] || [ "$x" -lt "$best" ]; then
          best="$x"
        fi
      fi
    done
  done < "$af"

  echo "$min $max $best"
}

gpu_set_minfreq_percent() {
  local d pct bounds min_sup max_sup target best cap current
  d="$1"
  pct="$2"
  case "$pct" in ""|*[!0-9]*) return 0 ;; esac
  [ "$pct" -gt 0 ] && [ "$pct" -le 100 ] || return 0
  [ -e "$d/min_freq" ] || return 0
  bounds="$(_gpu_scan_freq_tokens "$d" 0)"
  # Numeric tokens produced by _gpu_scan_freq_tokens.
  # shellcheck disable=SC2086
  set -- $bounds
  min_sup="$1"
  max_sup="$2"
  [ "$max_sup" -gt 0 ] || return 0
  # Preserve precision without overflowing mksh's 32-bit arithmetic.
  # shellcheck disable=SC2017
  target=$((max_sup / 100 * pct + max_sup % 100 * pct / 100))
  [ "$target" -lt "$min_sup" ] && target="$min_sup"
  bounds="$(_gpu_scan_freq_tokens "$d" "$target")"
  # Numeric tokens produced by _gpu_scan_freq_tokens.
  # shellcheck disable=SC2086
  set -- $bounds
  best="$3"
  [ "$best" -gt 0 ] || return 0
  cap="$(read_node "$d/max_freq")"
  case "$cap" in ""|*[!0-9]*) return 0 ;; esac
  # A zero devfreq limit means no explicit cap. Never raise max_freq.
  [ "$cap" -eq 0 ] || [ "$best" -le "$cap" ] || return 0
  current="$(read_node "$d/min_freq")"
  case "$current" in ""|*[!0-9]*) return 0 ;; esac
  [ "$best" -gt "$current" ] || return 0
  write_node "$d/min_freq" "$best"
}


# ---------------------------------------------------------------------
# GPU thermal guard (v2.7)
# GPU_HOT=1 -> GPU tweaks are released until the GPU cools down.
# ---------------------------------------------------------------------
GPU_HOT=0
GPU_TEMP_C=0

gpu_read_temp_c() {
  local t z
  t=""
  if [ -r /sys/class/kgsl/kgsl-3d0/temp ]; then
    read -r t < /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null
  fi
  case "$t" in ""|*[!0-9]*)
    t=""
    for z in /sys/class/thermal/thermal_zone*; do
      [ -r "$z/type" ] || continue
      read -r name < "$z/type" 2>/dev/null
      case "$name" in
        gpuss-*|gpu*|GPU*)
          read -r t < "$z/temp" 2>/dev/null
          case "$t" in ""|*[!0-9]*) t=""; continue ;; esac
          break
          ;;
      esac
    done
    ;;
  esac
  case "$t" in ""|*[!0-9]*) echo 0; return 0 ;; esac
  # kgsl/thermal report millidegrees C; accept plain degrees too.
  [ "$t" -gt 1000 ] && t=$((t / 1000))
  echo "$t"
}

gpu_thermal_check() {
  local hot resume
  GPU_TEMP_C="$(gpu_read_temp_c)"
  [ "$(get_prop_bool gpu.thermal.guard 1)" -eq 1 ] || { GPU_HOT=0; return 0; }
  [ "$GPU_TEMP_C" -gt 0 ] || return 0
  hot="$(get_prop_range gpu.thermal.hot_c 80 40 120)"
  resume="$(get_prop_range gpu.thermal.resume_c 72 30 119)"
  if [ "$GPU_HOT" -eq 0 ] && [ "$GPU_TEMP_C" -ge "$hot" ]; then
    GPU_HOT=1
    log_w "GPU thermal guard: ${GPU_TEMP_C}C >= ${hot}C, releasing GPU tweaks"
    apply_gpu_profile on
  elif [ "$GPU_HOT" -eq 1 ] && [ "$GPU_TEMP_C" -le "$resume" ]; then
    GPU_HOT=0
    log_i "GPU thermal guard: ${GPU_TEMP_C}C <= ${resume}C, re-applying GPU tweaks"
    apply_gpu_profile on
  fi
}

# Profile -> minimum frequency (Hz). Adreno 830 steps (MHz):
# 160 222 342 389 443 525 607 660 734 832 900 967 1050 1100
gpu_profile_floor_hz() {
  case "$(get_prop gpu.profile performance)" in
    balanced)    echo 443000000 ;;
    performance) echo 660000000 ;;
    extreme)     echo 832000000 ;;
    custom)      get_prop_range gpu.min_freq_hz.on 443000000 0 2000000000 ;;
    *)           echo 660000000 ;;
  esac
}

# Write a numeric prop to a node, or restore the baseline when unset ("keep").
gpu_apply_optional() {
  local node val
  node="$1"
  val="$(get_prop "$2" keep)"
  case "$val" in
    ""|*[!0-9]*) brestore "$node" ;;
    *) write_node_if_exists "$node" "$val" ;;
  esac
}

gpu_apply_test_governor() {
  local node available test_key
  node=/sys/class/kgsl/kgsl-3d0/devfreq/governor
  test_key="$1"
  if [ "$test_key" = "clk_bus_gov" ]; then
    available="$(read_node /sys/class/kgsl/kgsl-3d0/devfreq/available_governors 2>/dev/null)"
    case " $available " in
      *" msm-adreno-tz "*) write_node_if_exists "$node" msm-adreno-tz ;;
      *) log_w "GPU test governor msm-adreno-tz not listed; leaving governor unchanged"; brestore "$node" ;;
    esac
  else
    brestore "$node"
  fi
}

gpu_release_all() {
  local d n
  for d in $(gpu_nodes_iter); do
    brestore "$d/min_freq"
  done
  brestore /sys/class/devfreq/kgsl-busmon/min_freq
  brestore /sys/class/devfreq/3d00000.qcom,kgsl-3d0/min_freq
  brestore /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
  brestore /sys/class/kgsl/kgsl-3d0/idle_timer
  brestore /sys/class/kgsl/kgsl-3d0/devfreq/governor
  for n in force_clk_on force_bus_on force_rail_on force_no_nap bus_split minbw_timer; do
    brestore "/sys/class/kgsl/kgsl-3d0/$n"
  done
}

apply_gpu_profile() {
  local d pct hz_val idle_timer cap current bounds best n test_key want
  [ "$HAS_GPU_DEVFREQ" -eq 1 ] || return 0
  if [ "$1" != "on" ] || [ "$(get_prop_bool gpu.tuning.enable 0)" -ne 1 ] || [ "$GPU_HOT" -eq 1 ]; then
    gpu_release_all
    return 0
  fi

  hz_val="$(gpu_profile_floor_hz)"
  if [ "$hz_val" -gt 0 ] 2>/dev/null; then
    # Snap to the nearest supported step at or above the target.
    bounds="$(_gpu_scan_freq_tokens /sys/class/kgsl/kgsl-3d0/devfreq "$hz_val")"
    # shellcheck disable=SC2086
    set -- $bounds
    [ "${3:-0}" -gt 0 ] 2>/dev/null && hz_val="$3"
    for d in $(gpu_nodes_iter); do
      [ -e "$d/min_freq" ] || continue
      cap="$(read_node "$d/max_freq")"
      case "$cap" in ""|*[!0-9]*) cap=0 ;; esac
      [ "$cap" -eq 0 ] || [ "$hz_val" -le "$cap" ] || continue
      current="$(read_node "$d/min_freq")"
      case "$current" in ""|*[!0-9]*) continue ;; esac
      [ "$hz_val" -ne "$current" ] && write_node "$d/min_freq" "$hz_val"
    done
  else
    pct="$(get_prop_range gpu.min_freq_pct.on 0 0 100)"
    for d in $(gpu_nodes_iter); do
      gpu_set_minfreq_percent "$d" "$pct"
    done
  fi
  idle_timer="$(get_prop_range gpu.kgsl_idle_timer_ms 64 0 5000)"
  write_node_if_exists /sys/class/kgsl/kgsl-3d0/idle_timer "$idle_timer"

  # Power-gating overrides (heat/battery cost). Released by the thermal guard.
  test_key=""
  [ -f "$STATE_DIR/gpu_test" ] && test_key="$(read_first_line "$STATE_DIR/gpu_test" 2>/dev/null)"
  for n in force_clk_on force_bus_on force_rail_on force_no_nap; do
    want=0
    if [ -n "$test_key" ]; then
      # Action cycle presets; only the selected test configuration is applied.
      case "$test_key" in
        only_nap) want=0; [ "$n" = "force_no_nap" ] && want=1 ;;
        clk) want=1; [ "$n" = "force_clk_on" ] && want=0 ;;
        clk_bus|clk_bus_gov)
          want=1
          case "$n" in force_clk_on|force_bus_on) want=0 ;; esac
          ;;
        none) want=0 ;;
        *) want=0 ;;
      esac
    else
      want="$(get_prop_bool "gpu.$n" 0)"
    fi
    if [ "$want" -eq 1 ]; then
      write_node_if_exists "/sys/class/kgsl/kgsl-3d0/$n" 1
    elif [ -n "$test_key" ]; then
      write_node_if_exists "/sys/class/kgsl/kgsl-3d0/$n" 0
    else
      brestore "/sys/class/kgsl/kgsl-3d0/$n"
    fi
  done

  gpu_apply_test_governor "$test_key"

  # Bus / memory votes: "keep" leaves the device value alone.
  gpu_apply_optional /sys/class/kgsl/kgsl-3d0/bus_split gpu.bus_split
  gpu_apply_optional /sys/class/kgsl/kgsl-3d0/minbw_timer gpu.minbw_timer
}

mount_dev_for_mp() {
  local _id _parent dev _root mp _rest
  while read -r _id _parent dev _root mp _rest; do
    [ "$mp" = "$1" ] || continue
    readlink -f "/sys/dev/block/$dev" 2>/dev/null
    return
  done < /proc/self/mountinfo
  return 1
}

io_blacklisted() {
  case "$1" in
    ""|loop*|ram*|zram*) return 0 ;;
  esac
  return 1
}

_io_add_target() {
  local path child dev
  path="$(readlink -f "$1" 2>/dev/null)"
  [ -d "$path" ] || return 0
  [ -e "$path/partition" ] && path="${path%/*}"
  dev="${path##*/}"
  io_blacklisted "$dev" && return 0
  case " $IO_VISITED " in *" $dev "*) return 0 ;; esac
  IO_VISITED="$IO_VISITED $dev"
  [ -d "$path/queue" ] && IO_TARGETS="$IO_TARGETS $path/queue"
  for child in "$path"/slaves/*; do
    [ -e "$child" ] && _io_add_target "$child"
  done
  return 0
}

_io_collect_targets() {
  local IO_TARGETS IO_VISITED mp path
  IO_TARGETS=""
  IO_VISITED=""
  for mp in /data /; do
    path="$(mount_dev_for_mp "$mp")"
    [ -n "$path" ] && _io_add_target "$path"
  done
  echo "$IO_TARGETS"
}

apply_io_profile() {
  local q ra
  ra="$(get_prop_range io.read_ahead_kb.on 128 0 512)"
  for q in $(_io_collect_targets); do
    if [ "$1" = "on" ] && [ "$(get_prop_bool io.read_ahead.enable 0)" -eq 1 ]; then
      write_node_if_exists "$q/read_ahead_kb" "$ra"
    else
      brestore "$q/read_ahead_kb"
    fi
    # Keep vendor scheduler, request merging/depth, affinity and accounting.
  done
}

apply_net_profile() {
  mode="$1"

  if [ "$(get_prop_bool net.tcp_low_latency.enable 0)" -eq 1 ]; then
    if [ "$mode" = "on" ]; then
      write_node_if_exists "/proc/sys/net/ipv4/tcp_low_latency" "1"
    else
      brestore "/proc/sys/net/ipv4/tcp_low_latency"
    fi
  fi

  if [ "$(get_prop_bool net.tcp_timestamps.disable 0)" -eq 1 ]; then
    if [ "$mode" = "on" ]; then
      write_node_if_exists "/proc/sys/net/ipv4/tcp_timestamps" "0"
    else
      brestore "/proc/sys/net/ipv4/tcp_timestamps"
    fi
  fi
}

apply_mem_profile() {
  local mode swappiness dirty dirty_bg
  mode="$1"
  if [ "$(get_prop_bool mem.tuning.enable 0)" -ne 1 ]; then
    return 0
  fi

  if [ "$mode" = "on" ]; then
    swappiness="$(get_prop_range mem.swappiness 80 0 200)"
    dirty="$(get_prop_range mem.dirty_ratio 20 5 50)"
    dirty_bg="$(get_prop_range mem.dirty_background_ratio 10 2 30)"
    write_node_if_exists /proc/sys/vm/swappiness "$swappiness"
    write_node_if_exists /proc/sys/vm/dirty_ratio "$dirty"
    write_node_if_exists /proc/sys/vm/dirty_background_ratio "$dirty_bg"
    write_node_if_exists /proc/sys/vm/vfs_cache_pressure 100
  else
    brestore /proc/sys/vm/swappiness
    brestore /proc/sys/vm/dirty_ratio
    brestore /proc/sys/vm/dirty_background_ratio
    brestore /proc/sys/vm/vfs_cache_pressure
  fi
}

apply_display_profile() {
  local mode
  mode="$1"
  if [ "$mode" = "on" ]; then
    # Aggressive Mode: Disable all animations (0x) for instant response
    settings put global window_animation_scale 0 >/dev/null 2>&1
    settings put global transition_animation_scale 0 >/dev/null 2>&1
    settings put global animator_duration_scale 0 >/dev/null 2>&1
    settings put system window_animation_scale 0 >/dev/null 2>&1
    settings put system transition_animation_scale 0 >/dev/null 2>&1
    settings put system animator_duration_scale 0 >/dev/null 2>&1

    # Disable HW Overlays: Force GPU composition for lowest display latency
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1

    # Stop gameopt HAL backend service (UI / game space remains usable)
    stop gameopt_hal_service-1-0 >/dev/null 2>&1
  else
    # Stock Mode: Restore default animations (1.0x)
    settings put global window_animation_scale 1.0 >/dev/null 2>&1
    settings put global transition_animation_scale 1.0 >/dev/null 2>&1
    settings put global animator_duration_scale 1.0 >/dev/null 2>&1
    settings put system window_animation_scale 1.0 >/dev/null 2>&1
    settings put system transition_animation_scale 1.0 >/dev/null 2>&1
    settings put system animator_duration_scale 1.0 >/dev/null 2>&1

    # Restore HW Overlays: Enable default HWC composition
    service call SurfaceFlinger 1008 i32 0 >/dev/null 2>&1

    # Start gameopt HAL backend service
    start gameopt_hal_service-1-0 >/dev/null 2>&1
  fi
}

apply_profile() {
  local mode
  mode="$1"
  echo "$(read_first_line /proc/sys/kernel/random/boot_id) $mode" > "$STATE_DIR/apply_pending"
  log_i "PROFILE: $mode begin"
  log_i "STAGE: CPU"
  apply_cpu_profile "$mode"
  log_i "STAGE: UCLAMP"
  apply_uclamp_profile "$mode"
  log_i "STAGE: TOUCH"
  apply_touchboost "$mode"
  log_i "STAGE: GPU"
  apply_gpu_profile "$mode"
  log_i "STAGE: IO"
  apply_io_profile "$mode"
  log_i "STAGE: MEM"
  apply_mem_profile "$mode"
  log_i "STAGE: NET"
  apply_net_profile "$mode"
  log_i "STAGE: DISPLAY"
  apply_display_profile "$mode"
  log_i "PROFILE: $mode complete"
  rm -f "$STATE_DIR/apply_pending" "$STATE_DIR/crash_count"
}

contains() {
  hay="$1"
  needle="$2"
  case "$hay" in
    *"$needle"*) return 0 ;;
  esac
  return 1
}

is_screen_on_sysfs() {
  local bl v op drm f
  # 1. Backlight brightness (Universal across Android 12-15 / OxygenOS 15)
  for bl in /sys/class/backlight/*/brightness; do
    [ -e "$bl" ] || continue
    v=""
    read -r v < "$bl" 2>/dev/null
    case "$v" in
      ""|*[!0-9]*) continue ;;
      0) return 1 ;; # Screen backlight is off
      *) return 0 ;; # Screen backlight is on
    esac
  done

  # 2. OnePlus / OPLUS specific display power status
  for op in /sys/kernel/oplus_display/power_status /sys/devices/virtual/oplus_display/power_status; do
    [ -e "$op" ] || continue
    v=""
    read -r v < "$op" 2>/dev/null
    case "$v" in
      1|*on*|*ON*) return 0 ;;
      0|*off*|*OFF*) return 1 ;;
    esac
  done

  # 3. DRM KMS panel status (modern Qualcomm Linux 6.1/6.6 GKI)
  for drm in /sys/class/drm/card0-*/dpms /sys/class/drm/card0-*/enabled; do
    [ -e "$drm" ] || continue
    v=""
    read -r v < "$drm" 2>/dev/null
    case "$v" in
      0|*enabled*|*On*|*ON*) return 0 ;;
      1|2|3|*disabled*|*Off*|*OFF*) return 1 ;;
    esac
  done

  # 4. Legacy framebuffer fallback
  for f in /sys/class/graphics/fb0/blank /sys/class/graphics/fb1/blank; do
    [ -e "$f" ] || continue
    v=""
    read -r v < "$f" 2>/dev/null
    case "$v" in
      0) return 0 ;;
      1|2|4) return 1 ;;
    esac
  done

  return 2
}

is_screen_on() {
  is_screen_on_sysfs
  r="$?"

  [ "$r" = "0" ] && return 0
  [ "$r" = "1" ] && return 1

  # Fallback to dumpsys only if sysfs didn't provide state
  out="$(dumpsys -t 2 power 2>/dev/null)"
  if [ -n "$out" ]; then
    contains "$out" "mInteractive=false" && return 1
    contains "$out" "mWakefulness=Asleep" && return 1
    contains "$out" "mWakefulness=Dozing" && return 1
    contains "$out" "mInteractive=true" && return 0
    contains "$out" "mWakefulness=Awake" && return 0
    contains "$out" "Display Power: state=ON" && return 0
  fi

  out2="$(dumpsys -t 2 display 2>/dev/null)"
  if [ -n "$out2" ]; then
    contains "$out2" "mState=ON" && return 0
    contains "$out2" "mState=OFF" && return 1
  fi

  # Under heavy load (gaming), dumpsys may time out. Do not assume screen off.
  [ "${last_effective:-}" = "on" ] && return 0
  return 0
}

stable_screen_state() {
  local s1 s2
  if is_screen_on; then
    s1="on"
  else
    s1="off"
  fi

  # Confirm transitions only; avoid a second probe on every idle poll.
  [ "$s1" = "${last_effective:-}" ] && { echo "$s1"; return 0; }
  akt_sleep 1

  if is_screen_on; then
    s2="on"
  else
    s2="off"
  fi

  [ "$s1" = "$s2" ] && echo "$s1" || echo ""
}

topapp_min_nodes() {
  local node cg_top
  for node in /dev/stune/top-app/uclamp.min /dev/cpuset/top-app/uclamp.min; do
    [ -e "$node" ] && echo "$node"
  done
  cg_top="$(cg_find_group top-app)"
  [ -n "$cg_top" ] && [ -e "$cg_top/cpu.uclamp.min" ] && echo "$cg_top/cpu.uclamp.min"
  return 0
}

set_topapp_min_all_bases() {
  local node val pct val_pct current current_units whole frac
  val="$1"
  for node in $(topapp_min_nodes); do
    current="$(read_node "$node")"
    case "$node" in
      */cpu.uclamp.min)
        pct=$((val * 10000 / 1024))
        whole="${current%%.*}"
        frac="${current#*.}"
        [ "$frac" = "$current" ] && frac=0
        # Compare in hundredths without floating-point tools.
        case "$whole:$frac" in *[!0-9:]*|:*) continue ;; esac
        frac="${frac}00"
        frac="${frac%"${frac#??}"}"
        current_units=$((whole * 100 + 10#$frac))
        [ "$pct" -gt "$current_units" ] || continue
        frac="$((pct % 100))"
        [ "$frac" -lt 10 ] && frac="0$frac"
        val_pct="$((pct / 100)).$frac"
        write_node "$node" "$val_pct"
        ;;
      *)
        case "$current" in ""|*[!0-9]*) continue ;; esac
        [ "$val" -gt "$current" ] && write_node "$node" "$val"
        ;;
    esac
  done
  return 0
}

effective_state_from_mode() {
  fm="$1"
  case "$fm" in
    stock|strict) echo "off" ;;
    aggressive|*) echo "on" ;;
  esac
}

enforce_aggressive_watchdog() {
  local cur_up cur_gpu
  # Check WALT rate limit on policy0
  cur_up="$(read_node /sys/devices/system/cpu/cpufreq/policy0/walt/up_rate_limit_us 2>/dev/null)"
  case "$cur_up" in
    ""|0)
      write_node_if_exists /sys/devices/system/cpu/cpufreq/policy0/walt/up_rate_limit_us 500
      write_node_if_exists /sys/devices/system/cpu/cpufreq/policy0/walt/down_rate_limit_us 40000
      write_node_if_exists /sys/devices/system/cpu/cpufreq/policy0/walt/hispeed_load 75
      write_node_if_exists /sys/devices/system/cpu/cpufreq/policy6/walt/up_rate_limit_us 500
      write_node_if_exists /sys/devices/system/cpu/cpufreq/policy6/walt/down_rate_limit_us 40000
      write_node_if_exists /sys/devices/system/cpu/cpufreq/policy6/walt/hispeed_load 70
      ;;
  esac

  # Check GPU devfreq min_freq
  cur_gpu="$(read_node /sys/class/kgsl/kgsl-3d0/devfreq/min_freq 2>/dev/null)"
  case "$cur_gpu" in
    ""|160000000|222000000|342000000|389000000)
      write_node_if_exists /sys/class/kgsl/kgsl-3d0/devfreq/min_freq 443000000
      write_node_if_exists /sys/class/devfreq/3d00000.qcom,kgsl-3d0/min_freq 443000000
      write_node_if_exists /sys/class/devfreq/kgsl-busmon/min_freq 443000000
      write_node_if_exists /sys/class/kgsl/kgsl-3d0/idle_timer 64
      ;;
  esac

  write_node_if_exists /proc/sys/walt/sched_low_latency 1
  write_node_if_exists /proc/sys/walt/sched_boost 1
}

# AKTune-priority mode (v2.7.1): AKTune owns the tunables.
# Cheap by design: each tick only reads a few key nodes with shell builtins
# (no forks) and builds a signature. A full re-apply runs only when the
# signature changed (the device or another module touched a value), on
# screen-on, or every 10th tick as a safety net.
prio_signature() {
  local f v sig
  sig=""
  for f in \
    /sys/class/kgsl/kgsl-3d0/devfreq/min_freq \
    /sys/class/kgsl/kgsl-3d0/idle_timer \
    /sys/devices/system/cpu/cpufreq/policy0/walt/up_rate_limit_us \
    /sys/devices/system/cpu/cpufreq/policy0/walt/hispeed_load \
    /sys/devices/system/cpu/cpufreq/policy6/walt/up_rate_limit_us \
    /sys/devices/system/cpu/cpufreq/policy6/walt/hispeed_load \
    /proc/sys/walt/sched_boost \
    /proc/sys/walt/sched_low_latency \
    /sys/class/kgsl/kgsl-3d0/force_clk_on \
    /sys/class/kgsl/kgsl-3d0/force_bus_on \
    /sys/class/kgsl/kgsl-3d0/force_rail_on \
    /sys/class/kgsl/kgsl-3d0/force_no_nap \
    /sys/class/kgsl/kgsl-3d0/bus_split \
    /sys/class/kgsl/kgsl-3d0/minbw_timer \
    /dev/stune/top-app/uclamp.min; do
    v=""
    [ -r "$f" ] && read -r v < "$f" 2>/dev/null
    sig="$sig|$v"
  done
  v=""
  [ -r "$STATE_DIR/gpu_test" ] && read -r v < "$STATE_DIR/gpu_test" 2>/dev/null
  sig="$sig|test=$v"
  # gpu.* config lines: editing config.props takes effect on the next tick.
  if [ -r "$CONFIG_FILE" ]; then
    while IFS= read -r v || [ -n "$v" ]; do
      case "$v" in gpu.*) sig="$sig|$v" ;; esac
    done < "$CONFIG_FILE"
  fi
  echo "$sig"
}

enforce_priority() {
  local sig
  priority_tick=$(( ${priority_tick:-0} + 1 ))
  sig="$(prio_signature)"
  if [ "$sig" != "${last_prio_sig:-}" ] || [ $((priority_tick % 10)) -eq 0 ] || [ "${force_full:-0}" -eq 1 ]; then
    force_full=0
    apply_cpu_profile on
    apply_uclamp_profile on
    apply_gpu_profile on
    if [ $((priority_tick % 10)) -eq 0 ]; then
      apply_io_profile on
      apply_mem_profile on
    fi
    write_node_if_exists /proc/sys/walt/sched_low_latency 1
    write_node_if_exists /proc/sys/walt/sched_boost 1
    last_prio_sig="$(prio_signature)"
  fi
}

write_status() {
  {
    echo "priority=$1"
    echo "gpu_profile=$(get_prop gpu.profile performance)"
    echo "gpu_temp_c=$GPU_TEMP_C"
    echo "gpu_thermal_released=$GPU_HOT"
    echo "gpu_min_freq=$(read_node /sys/class/kgsl/kgsl-3d0/devfreq/min_freq 2>/dev/null)"
    echo "gpu_test=$(read_first_line "$STATE_DIR/gpu_test" 2>/dev/null)"
    echo "gpu_governor=$(read_node /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null)"
    echo "force_clk_on=$(read_node /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null)"
    echo "force_bus_on=$(read_node /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null)"
    echo "force_rail_on=$(read_node /sys/class/kgsl/kgsl-3d0/force_rail_on 2>/dev/null)"
    echo "force_no_nap=$(read_node /sys/class/kgsl/kgsl-3d0/force_no_nap 2>/dev/null)"
    echo "bus_split=$(read_node /sys/class/kgsl/kgsl-3d0/bus_split 2>/dev/null)"
    echo "minbw_timer=$(read_node /sys/class/kgsl/kgsl-3d0/minbw_timer 2>/dev/null)"
    echo "gpu_cur_freq=$(read_node /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq 2>/dev/null)"
  } > "$STATE_DIR/status" 2>/dev/null
}

# ColorOS resets "Disable HW overlays" when the refresh mode changes
# (Champion mode / game launch). Re-assert it periodically in aggressive mode.
reassert_overlays() {
  local now_t gap
  now_t="$1"
  gap="$(get_prop_range display.overlay_reassert_sec 20 0 600)"
  case "$gap" in ""|*[!0-9]*) gap=20 ;; esac
  [ "$gap" -gt 0 ] || return 0
  [ $((now_t - ${last_overlay_ts:-0})) -ge $((gap * 1000)) ] || return 0
  service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
  last_overlay_ts="$now_t"
}

acquire_daemon_lock() {
  local boot old_lock
  boot="$(read_first_line /proc/sys/kernel/random/boot_id)"
  [ -n "$boot" ] || return 1
  DAEMON_LOCK="$STATE_DIR/daemon.$boot.lock"
  # Fail closed on an occupied lock, including after SIGKILL in this boot.
  if [ -d "$DAEMON_LOCK" ]; then
    old_lock=""
    read -r old_lock < "$DAEMON_LOCK/pid" 2>/dev/null
    case "$old_lock" in ""|*[!0-9]*) old_lock=0 ;; esac
    if [ "$old_lock" -le 1 ] || ! kill -0 "$old_lock" 2>/dev/null; then
      rm -f "$DAEMON_LOCK/pid"
      rmdir "$DAEMON_LOCK" 2>/dev/null
    fi
  fi
  mkdir "$DAEMON_LOCK" 2>/dev/null || return 1
  echo "$$" > "$DAEMON_LOCK/pid"
  echo "$$" > "$STATE_DIR/daemon.pid"
  trap 'release_daemon_lock' EXIT
  trap 'exit 0' HUP INT TERM
  for old_lock in "$STATE_DIR"/daemon.*.lock; do
    [ "$old_lock" = "$DAEMON_LOCK" ] && continue
    rm -f "$old_lock/pid"
    rmdir "$old_lock" 2>/dev/null
  done
  return 0
}

release_daemon_lock() {
  rm -f "$STATE_DIR/daemon.pid"
  rm -f "$DAEMON_LOCK/pid"
  rmdir "$DAEMON_LOCK" 2>/dev/null
}

main() {
  # Protect daemon from Android LowMemoryKiller (LMK)
  if [ -w "/proc/$$/oom_score_adj" ]; then
    echo "-900" > "/proc/$$/oom_score_adj" 2>/dev/null
  fi

  aktune_prepare_dirs
  rotate_logs_if_needed
  acquire_daemon_lock || { log_w "Another tuning process owns the lock"; return 1; }
  aktune_prepare_boot_state || return 1
  local pending_boot pending_mode boot crashes
  boot="$(read_first_line /proc/sys/kernel/random/boot_id)"
  if [ -f "$STATE_DIR/apply_pending" ]; then
    pending_boot=""; pending_mode=""
    read -r pending_boot pending_mode < "$STATE_DIR/apply_pending" 2>/dev/null
    if [ "$pending_boot" != "$boot" ]; then
      # Stale marker from an interrupted profile (or an empty/corrupt file).
      # Self-heal: clear it and retry; pause only after 3 crashes in a row.
      crashes="$(read_first_line "$STATE_DIR/crash_count" 2>/dev/null)"
      case "$crashes" in ""|*[!0-9]*) crashes=0 ;; esac
      crashes=$((crashes + 1))
      if [ "$crashes" -ge 4 ]; then
        log_e "Tuning paused: profile ${pending_mode:-?} crashed $((crashes - 1)) boots in a row; press the module Action button to retry"
        return 1
      fi
      echo "$crashes" > "$STATE_DIR/crash_count"
      log_w "Stale apply_pending (profile ${pending_mode:-?}) cleared automatically; retry $crashes/3"
      rm -f "$STATE_DIR/apply_pending"
    fi
  fi
  log_i "Kernel: $(uname -a)"
  detect_platform
  if [ "${1:-}" = "--oneshot" ]; then
    apply_profile on
    return
  fi

  interval="$(get_prop_range daemon.interval_sec 4 2 300)"
  debounce_ms="$(get_prop_range daemon.debounce_ms 1000 0 60000)"

  case "$interval" in
    ""|*[!0-9]*) interval="4" ;;
    0) interval="4" ;;
  esac

  last_effective=""
  last_change_ts=0
  last_forced=""
  last_overlay_ts=0

  forced="$(read_forced_mode)"
  st="$(effective_state_from_mode "$forced")"

  if [ -n "$st" ]; then
    log_i "MODE: $forced (initial)"
    apply_profile "$st"
    last_effective="$st"
    last_change_ts="$(now_ms)"
    last_forced="$forced"
  fi

  while true; do
    now="$(now_ms)"
    forced="$(read_forced_mode)"

    if [ "$forced" != "$last_forced" ]; then
      log_i "MODE: changed $last_forced -> $forced"
      st="$(effective_state_from_mode "$forced")"
      if [ -n "$st" ]; then
        apply_profile "$st"
        last_effective="$st"
        last_change_ts="$now"
      fi
      last_forced="$forced"
      akt_sleep "$interval"
      continue
    fi

    cur_test="$(read_first_line "$STATE_DIR/gpu_test" 2>/dev/null)"
    if [ "$cur_test" != "${last_test:-$cur_test}" ] && [ "$forced" = "aggressive" ]; then
      log_i "GPU test: ${last_test:-} -> $cur_test"
      apply_gpu_profile on
    fi
    last_test="$cur_test"
    prio="$(get_prop priority.mode aktune)"
    # Screen off: do nothing and sleep long (lets the CPU idle deeply).
    if [ "$forced" = "aggressive" ]; then
      is_screen_on_sysfs
      if [ "$?" -eq 1 ]; then
        screen_was_off=1
        write_status "$prio(screen-off)"
        akt_sleep "$(get_prop_range priority.screen_off_sec 30 5 600)"
        continue
      fi
      if [ "${screen_was_off:-0}" -eq 1 ]; then
        screen_was_off=0
        force_full=1
      fi
    fi
    if [ "$forced" = "aggressive" ]; then
      gpu_thermal_check
      if [ "$prio" = "aktune" ]; then
        enforce_priority
      else
        prio="device"
        enforce_aggressive_watchdog
      fi
      reassert_overlays "$now"
    else
      GPU_HOT=0
    fi

    write_status "$prio"
    loop_n=$(( ${loop_n:-0} + 1 ))
    [ $((loop_n % 200)) -eq 0 ] && rotate_logs_if_needed
    if [ "$forced" = "aggressive" ] && [ "$prio" = "aktune" ]; then
      akt_sleep "$(get_prop_range priority.interval_sec 6 1 60)"
    else
      akt_sleep "$interval"
    fi
  done
}

main "$@"
