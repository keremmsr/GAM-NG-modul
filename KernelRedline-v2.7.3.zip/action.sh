#!/system/bin/sh
MODDIR="${0%/*}"
export AKTUNE_MODDIR="$MODDIR"

# Load helpers/paths
. "$MODDIR/common/util.sh"

aktune_prepare_dirs

MODE_FILE="$STATE_DIR/force_mode"

read_mode() {
  if [ -f "$MODE_FILE" ]; then
    m="$(read_first_line "$MODE_FILE" 2>/dev/null)"
    m="$(akt_trim_ws "$m")"
    case "$m" in
      aggressive|stock) echo "$m"; return 0 ;;
    esac
  fi
  echo "aggressive"
}

next_mode() {
  case "$1" in
    aggressive) echo "stock" ;;
    stock|*) echo "aggressive" ;;
  esac
}

mode_desc() {
  case "$1" in
    aggressive)
      echo "AGGRESSIVE: Full Gaming Mode"
      echo "  - CPU: WALT 500us / Down 40ms"
      echo "  - GPU: profile floor (see config gpu.profile) + thermal guard"
      echo "  - Priority: Kernel Redline overrides device (priority.mode)"
      echo "  - Display: 0x Animations + HW Overlays Disabled"
      echo "  - GameOPT: HAL Service Stopped (UI accessible)"
      ;;
    stock)
      echo "STOCK: Factory Default Mode"
      echo "  - CPU & GPU: Restored to baseline"
      echo "  - Display: 1.0x Animations + Default HW Overlays"
      echo "  - GameOPT: HAL Service Started"
      ;;
  esac
}

# --- GPU test sequence (v2.7.3): every press advances one step --------------
# 1: force_no_nap ON; the other three force_* OFF
# 2: only force_clk_on OFF; the other three ON
# 3: force_clk_on + force_bus_on OFF; the other two ON
# 4: same as 3, and explicitly select msm-adreno-tz if the kernel lists it
# 5: v2.7.2-like (all force_* OFF; bus_split/minbw_timer stay at device values)
# 6: STOCK mode
# Versioned counter starts this revised sequence at step 1, independent of
# the previous v2.7.3 cycle's stored test_step value.
STEP_FILE="$STATE_DIR/gpu_test_step_v273"
TEST_FILE="$STATE_DIR/gpu_test"

cur="$(read_mode)"
step="$(read_first_line "$STEP_FILE" 2>/dev/null)"
case "$step" in
  0|1|2|3|4|5|6) ;;
  *) step=0 ;;
esac
[ "$step" -lt 6 ] || step=0
step=$((step + 1))
echo "$step" > "$STEP_FILE" 2>/dev/null

case "$step" in
  1) nxt="aggressive"; test_key="only_nap";    step_name="1/6: force_no_nap ACIK, diger 3 KAPALI" ;;
  2) nxt="aggressive"; test_key="clk";         step_name="2/6: sadece force_clk_on KAPALI" ;;
  3) nxt="aggressive"; test_key="clk_bus";     step_name="3/6: force_clk_on + force_bus_on KAPALI" ;;
  4) nxt="aggressive"; test_key="clk_bus_gov"; step_name="4/6: 3. adim + msm-adreno-tz governor" ;;
  5) nxt="aggressive"; test_key="none";        step_name="5/6: v2.7.2 GIBI (4 force kapali, bus keep)" ;;
  6) nxt="stock";      test_key="none";        step_name="6/6: STOK MOD" ;;
esac

echo "$test_key" > "$TEST_FILE" 2>/dev/null
echo "$nxt" > "$MODE_FILE" 2>/dev/null
# Manual press = explicit retry: clear any stale crash marker
rm -f "$STATE_DIR/apply_pending" "$STATE_DIR/crash_count" 2>/dev/null

log_i "action: test step $step ($test_key), mode $cur -> $nxt"

echo ""
echo "========================================"
echo "Kernel Redline v2.7.3: GPU Test Dongusu"
echo "----------------------------------------"
echo "Adim:     $step_name"
echo "Mod:      $cur -> $nxt"
echo "Sonraki:  tusa tekrar bas (1->2->3->4->5->6->1)"
echo "----------------------------------------"
mode_desc "$nxt"
echo "========================================"
echo ""

# If daemon is running, it will observe the change on next poll.
# Also wake/trigger daemon immediately if possible.
if aktune_daemon_running; then
  log_i "action: mode applied to running daemon"
  if [ "$nxt" = "aggressive" ]; then
    settings put global window_animation_scale 0 >/dev/null 2>&1
    settings put global transition_animation_scale 0 >/dev/null 2>&1
    settings put global animator_duration_scale 0 >/dev/null 2>&1
    settings put system window_animation_scale 0 >/dev/null 2>&1
    settings put system transition_animation_scale 0 >/dev/null 2>&1
    settings put system animator_duration_scale 0 >/dev/null 2>&1
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
    stop gameopt_hal_service-1-0 >/dev/null 2>&1
  else
    settings put global window_animation_scale 1.0 >/dev/null 2>&1
    settings put global transition_animation_scale 1.0 >/dev/null 2>&1
    settings put global animator_duration_scale 1.0 >/dev/null 2>&1
    settings put system window_animation_scale 1.0 >/dev/null 2>&1
    settings put system transition_animation_scale 1.0 >/dev/null 2>&1
    settings put system animator_duration_scale 1.0 >/dev/null 2>&1
    service call SurfaceFlinger 1008 i32 0 >/dev/null 2>&1
    start gameopt_hal_service-1-0 >/dev/null 2>&1
  fi
  echo "Kernel Redline: Daemon updated to $nxt mode!"
  exit 0
fi

# If not running, start fresh daemon
if command -v nohup >/dev/null 2>&1; then
  nohup sh "$MODDIR/tweaks/daemon.sh" >> "$LOG_FILE" 2>&1 &
else
  sh "$MODDIR/tweaks/daemon.sh" >> "$LOG_FILE" 2>&1 &
fi

log_i "action: daemon restarted pid=$!"
echo "Kernel Redline: daemon started (pid=$!)"
echo ""
exit 0
