#!/system/bin/sh
MODDIR=${0%/*}
# Touch only module - ZRAM/memory tweaks removed (handled by other modules)