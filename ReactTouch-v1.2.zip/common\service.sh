#!/system/bin/sh
MODDIR=${0%/*}

while [ `getprop vendor.post_boot.parsed` != "1" ]; do
    sleep 1s
done

sleep 10s

# Force GPU for touch render
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;

# Touch Boost
echo '1' > /sys/module/msm_performance/parameters/touchboost
echo '1' > /sys/power/pnpmgr/touch_boost
